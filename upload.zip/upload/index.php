<script language="javascript">
     var mobile = (/iphone|ipad|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase()));
              if (mobile) {
                  window.location.href = "phone";
              }
              else
                  window.location.href = "pc";
			  </script>