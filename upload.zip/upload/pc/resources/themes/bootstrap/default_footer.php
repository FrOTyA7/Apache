<hr>

<div class="footer">
    Powered by, <a href="/">Anonymous
</a>
</div>
